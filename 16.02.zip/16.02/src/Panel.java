import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;


public class Panel extends JPanel implements MouseListener {


    public static Ball[] balls;

    int w = 550;
    int h = 300;
    int X = 70;
    int Y = 80;
    int n = 10;

    double xA;
    double yA;

    double xB;
    double yB;

    double cueX;
    double cueY;

    BufferedImage holeImage;

    Random r = new Random(387438473);

    Cue cue = new Cue();

    public Panel() throws IOException {

        balls = new Ball[n];
        for (int i = 0; i < n; ++i) {

            balls[i] = new Ball(r.nextInt(450) + X + 10, r.nextInt(360) + Y);
        }
        this.holeImage = ImageIO.read(new File("D:\\Pool\\src\\16.02\\src\\Безымянный.png"));
        this.addMouseListener(this);
        this.addMouseMotionListener(cue);

    }

    protected void paintComponent(Graphics g) {

        g.drawImage(holeImage, X, Y, w, h, null);

        for (int i = 0; i < n; i++) {

            balls[i].draw(g);
            balls[i].collide();
            cue.draw(g);
        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        xA = e.getX();
        yA = e.getY();

        cue.ChangeXY(xA, yA);

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
