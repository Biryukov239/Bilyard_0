import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Cue extends JPanel implements MouseMotionListener {

    double xA;
    double yA;

    double xB;
    double yB;

    int width = 300;
    int height = 300;

    BufferedImage cueImage;
    double angleInRadians;

    public void ChangeXY(double xA, double yA) {

        this.xA = xA;
        this.yA = yA;
    }

    public Cue() throws IOException {
        this.cueImage = ImageIO.read(new File("D:\\Pool\\src\\16.02\\src\\cue3.png"));
    }

    public void draw(Graphics g) {

        angleInRadians = Math.atan2(xB - xA, yB - yA);
        double locationX = cueImage.getWidth() / 2;
        double locationY = cueImage.getHeight() / 2;
        AffineTransform tx = AffineTransform.getRotateInstance(angleInRadians, locationX, locationY);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);

        g.drawImage(op.filter(cueImage, null), (int) xA, (int) yA, width, height, null);
        //g.drawImage(cueImage, (int) xA, (int) yA, width, height, null);
    }


    @Override
    public void mouseDragged(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        xB = e.getX();
        yB = e.getY();
    }
}
