package KartohaEngine2D.drawing;

import java.awt.*;

public interface Drawable {

    void draw(Graphics g);

}
