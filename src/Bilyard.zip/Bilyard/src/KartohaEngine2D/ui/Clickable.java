package KartohaEngine2D.ui;

import java.awt.event.MouseEvent;

public interface Clickable {

    void handleClick(MouseEvent event);

}
