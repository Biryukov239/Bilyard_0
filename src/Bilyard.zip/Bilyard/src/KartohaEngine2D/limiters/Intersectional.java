package KartohaEngine2D.limiters;

public interface Intersectional {}
