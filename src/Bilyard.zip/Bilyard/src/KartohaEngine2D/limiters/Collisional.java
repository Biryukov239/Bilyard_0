package KartohaEngine2D.limiters;

public interface Collisional {}
