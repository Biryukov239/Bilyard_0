package KartohaEngine2D.utils;

public interface Executable {
    void execute();
}
